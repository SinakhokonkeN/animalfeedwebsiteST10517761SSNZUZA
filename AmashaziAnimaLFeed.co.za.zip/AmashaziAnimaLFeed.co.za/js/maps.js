/* Google Maps JavaScript API, click-to-load, with a keyless area-map fallback.
   No device location is requested and no unverified store marker is displayed. */
(() => {
  'use strict';
  const cfg=window.AMASHAZI_CONFIG.maps;
  const root=document.getElementById('google-map');if(!root)return;
  const placeholder=document.querySelector('[data-map-placeholder]');
  const load=document.querySelector('[data-load-map]'),unload=document.querySelector('[data-unload-map]'),status=document.querySelector('[data-map-status]');
  let generation=0,map=null,marker=null,scriptPromise=null;
  const query=cfg.verifiedAddress&&window.AMASHAZI_CONFIG.business.address?window.AMASHAZI_CONFIG.business.address:cfg.areaQuery;
  document.querySelector('[data-maps-link]').href=`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`;
  function fallback(message){
    root.replaceChildren();const iframe=document.createElement('iframe');
    iframe.title='Google Maps view of the Bulwer area in KwaZulu-Natal';iframe.referrerPolicy='no-referrer-when-downgrade';iframe.allowFullscreen=true;
    iframe.src=`https://www.google.com/maps?q=${encodeURIComponent(query)}&output=embed`;
    root.append(iframe);root.hidden=false;placeholder.hidden=true;unload.hidden=false;
    status.textContent=message||'Google area view. This is not a confirmed business pin. If the map is unavailable, use “Open in Google Maps”.';
  }
  function loadApi(){
    if(window.google?.maps?.importLibrary)return Promise.resolve();
    if(scriptPromise)return scriptPromise;
    scriptPromise=new Promise((resolve,reject)=>{
      let timer;const script=document.createElement('script');
      const done=error=>{clearTimeout(timer);if(error){scriptPromise=null;script.remove();reject(error);}else resolve();};
      window.amashaziMapsReady=()=>done();
      window.gm_authFailure=()=>{done(new Error('Maps authorisation failed'));if(!root.hidden)fallback('The interactive map is unavailable. Showing the Google area view instead.');};
      const url=new URL('https://maps.googleapis.com/maps/api/js');
      Object.entries({key:cfg.apiKey,loading:'async',callback:'amashaziMapsReady',v:'weekly',language:'en',region:'ZA'}).forEach(([k,v])=>url.searchParams.set(k,v));
      script.src=url.href;script.async=true;script.onerror=()=>done(new Error('Maps could not load'));
      timer=setTimeout(()=>done(new Error('Maps load timed out')),12000);document.head.append(script);
    });
    return scriptPromise;
  }
  async function show(){
    const token=++generation;load.disabled=true;load.textContent='Loading map…';status.textContent='Connecting to Google Maps…';
    if(!cfg.apiKey){fallback();load.disabled=false;load.textContent='Load Google map ↗';return;}
    try{
      await loadApi();
      const {Map}=await google.maps.importLibrary('maps');
      if(token!==generation)return;
      const point=cfg.verifiedAddress&&cfg.verifiedPosition&&Number.isFinite(cfg.verifiedPosition.lat)&&Number.isFinite(cfg.verifiedPosition.lng)?cfg.verifiedPosition:null;
      root.hidden=false;placeholder.hidden=true;root.replaceChildren();unload.hidden=false;
      map=new Map(root,{center:point||cfg.areaCenter,zoom:point?15:7,mapId:cfg.mapId||'DEMO_MAP_ID',gestureHandling:'cooperative',streetViewControl:false,mapTypeControl:true,fullscreenControl:true});
      if(point){
        const {AdvancedMarkerElement}=await google.maps.importLibrary('marker');if(token!==generation)return;
        marker=new AdvancedMarkerElement({map,position:point,title:'Amashazi Animal Feed Suppliers'});
        status.textContent='Google Maps interactive view of the confirmed business location.';
      }else status.textContent='Interactive KwaZulu-Natal area map. No store marker is shown because the premises are not confirmed.';
    }catch{if(token===generation)fallback('The interactive map could not load. Showing the Google area view instead. You can also open Google Maps directly.');}
    finally{load.disabled=false;load.textContent='Load Google map ↗';}
  }
  load.addEventListener('click',show);
  unload.addEventListener('click',()=>{
    generation++;if(marker)marker.map=null;marker=null;map=null;root.replaceChildren();root.hidden=true;placeholder.hidden=false;unload.hidden=true;status.textContent='Map unloaded. Area view only; confirm the collection address before travelling.';load.focus();
  });
})();
