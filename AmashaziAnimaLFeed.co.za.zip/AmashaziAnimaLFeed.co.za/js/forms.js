(() => {
  'use strict';
  const form=document.querySelector('form[data-kind]');if(!form)return;
  const kind=form.dataset.kind,config=window.AMASHAZI_CONFIG;
  const $=s=>document.querySelector(s);
  const field=name=>form.elements.namedItem(name);
  const status=form.querySelector('.form-status');
  const result=$('[data-form-result]'),summary=$('[data-summary]'),resultStatus=$('[data-result-status]'),send=$('[data-submit-request]'),sendStatus=$('[data-submit-status]'),emailLink=$('[data-email-draft]');
  let prepared=null,available=false,busy=false;
  const localDate=()=>{const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;};
  form.noValidate=true;
  if(field('requiredDate'))field('requiredDate').min=localDate();
  function error(input,message='') {
    if(!input?.id)return;
    input.setAttribute('aria-invalid',String(!!message));
    const node=document.getElementById(`${input.id}-error`);if(node)node.textContent=message;
  }
  function chosenLines(){
    if(kind!=='enquiry')return [];
    const id=field('category').value;
    return id?[{id,quantity:Number(field('quantity').value)}]:window.AMASHAZI_QUOTE.getLines().map(({id,quantity})=>({id,quantity}));
  }
  function validate(){
    if(kind==='enquiry') {
      field('quantity').required=!!field('category').value;
      field('area').required=field('fulfilment').value==='delivery';
    }
    let first=null;
    [...form.elements].filter(input=>['INPUT','SELECT','TEXTAREA'].includes(input.tagName)&&input.name!=='website').forEach(input=>{
      if(input.type!=='checkbox'&&input.type!=='date')input.value=input.value.trim();
      let message='';
      if(!input.checkValidity()){
        if(input.validity.valueMissing)message=input.type==='checkbox'?'Please agree before preparing your request.':'Please complete this field.';
        else if(input.validity.typeMismatch)message='Enter a valid email address.';
        else if(input.validity.tooShort)message=`Please enter at least ${input.minLength} characters.`;
        else if(input.type==='date')message='Choose today or a later date.';
        else message='Enter a whole quantity between 1 and 999.';
      }
      if(input.name==='name'&&input.value.length<2)message='Enter your name using at least 2 characters.';
      if(input.name==='email'&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.value))message='Enter a valid email address, such as name@example.com.';
      if(input.name==='phone'&&input.value&&!/^\+?[\d\s()-]{7,25}$/.test(input.value))message='Use digits, spaces, brackets or a leading + for your phone number.';
      if(input.name==='phone'&&input.value){const n=input.value.replace(/\D/g,'').length;if(n<7||n>15)message='Enter a phone number containing 7–15 digits.';}
      if(input.name==='message'&&kind==='contact'&&input.value.length<10)message='Write a message of at least 10 characters.';
      if(kind==='enquiry'&&input.name==='category'&&!chosenLines().length)message='Choose a feed category or add items to your quote list.';
      error(input,message);if(message&&!first)first=input;
    });
    if(field('website').value)return false;
    if(first){status.textContent='Please check the highlighted fields.';status.classList.add('error');first.focus();return false;}
    status.classList.remove('error');return true;
  }
  function payload(){
    const values=Object.fromEntries(new FormData(form).entries());
    return {...values,kind,consent:field('consent').checked,items:chosenLines(),requestId:globalThis.crypto?.randomUUID?.()||`${Date.now()}-${Math.random().toString(36).slice(2)}`};
  }
  function buildSummary(data){
    const lines=[`AMASHAZI ANIMAL FEED SUPPLIERS — ${kind==='enquiry'?'FEED ENQUIRY':'GENERAL MESSAGE'}`,'',`Name: ${data.name}`,`Email: ${data.email}`,`Phone: ${data.phone||'Not supplied'}`];
    if(kind==='enquiry') {
      lines.push('', 'FEED REQUEST');
      data.items.forEach(line=>{const p=window.AMASHAZI_DATA.products.find(p=>p.id===line.id);lines.push(`${p.name}: approximately ${line.quantity} pack(s)`);});
      lines.push('',`Preference: ${data.fulfilment}`,`Area: ${data.area||'Not supplied'}`,`Preferred date: ${data.requiredDate||'To be agreed'}`,'','Cost: supplier quotation required.','Availability: supplier confirmation required.','Pack sizes and brands: to be confirmed.','Collection or delivery: subject to agreement.');
    } else lines.push(`Message type: ${data.subject}`);
    lines.push('','MESSAGE',data.message||'No additional notes.','','This summary is not an order, price quotation or proof of delivery.');
    return lines.join('\n');
  }
  function invalidate(){
    if(busy)return;
    if(prepared){prepared=null;result.hidden=true;status.textContent='Details changed. Prepare the summary again to use the latest information.';}
  }
  form.addEventListener('input',event=>{error(event.target);invalidate();});
  form.addEventListener('change',event=>{error(event.target);invalidate();});
  window.addEventListener('quotechange',invalidate);
  form.addEventListener('submit',event=>{
    event.preventDefault();if(!validate())return;
    prepared=payload();summary.textContent=buildSummary(prepared);result.hidden=false;send.disabled=false;send.hidden=!available;sendStatus.textContent='';
    resultStatus.textContent=available?'Review your summary, then choose “Record request” to save it with this website’s request service. No email is sent by that action.':'Your summary is ready and has not been sent. Download or copy it to keep your request.';
    const recipient=config.business.email;
    if(/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(recipient)){
      const subject=kind==='enquiry'?'Feed enquiry — Amashazi':`${prepared.subject} — Amashazi`;
      emailLink.href=`mailto:${recipient}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(summary.textContent)}`;emailLink.hidden=false;
    }else {emailLink.hidden=true;resultStatus.textContent+=' Direct business contact details are being confirmed.';}
    status.textContent='Summary prepared. Please review it below.';
    result.focus({preventScroll:true});result.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches||document.body.classList.contains('motion-paused')?'auto':'smooth',block:'start'});
  });
  async function request(url,options={},timeout=10000){
    const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),timeout);
    try{return await fetch(url,{...options,signal:controller.signal});}finally{clearTimeout(timer);}
  }
  // Only the local request-service capability is probed; no form data is sent here.
  if(location.protocol.startsWith('http'))request('api/health',{},2500).then(async response=>{
    const info=await response.json();available=response.ok&&info.service==='amashazi-requests'&&info.recording===true;
    if(prepared&&available){send.hidden=false;resultStatus.textContent='Your summary is ready. You can record it with this website’s request service; that does not send email.';}
  }).catch(()=>{available=false;});
  if(config.forms[`${kind}Endpoint`])available=true;
  send.addEventListener('click',async()=>{
    if(!prepared||busy)return;
    busy=true;send.disabled=true;send.textContent='Recording…';sendStatus.classList.remove('error');sendStatus.textContent='Recording your request…';
    const endpoint=config.forms[`${kind}Endpoint`]||form.getAttribute('action');
    try{
      const response=await request(endpoint,{method:form.method.toUpperCase(),headers:{'Content-Type':'application/json','Accept':'application/json'},body:JSON.stringify(prepared)});
      const data=await response.json();
      if(!response.ok||!data.ok||!data.reference)throw new Error('Request not confirmed');
      sendStatus.textContent=`Request recorded. Reference: ${data.reference}. Stock, pricing and fulfilment are not confirmed. No email has been sent.`;
      send.textContent='Request recorded';resultStatus.textContent='Your request has been recorded by this website’s request service.';
    }catch{
      sendStatus.classList.add('error');sendStatus.textContent='Recording could not be confirmed. Download your summary or try again. It has not been emailed.';send.disabled=false;send.textContent='Try recording again';
    }finally{busy=false;}
  });
  $('[data-copy]').addEventListener('click',async()=>{
    try{await navigator.clipboard.writeText(summary.textContent);window.AMASHAZI_UI.toast('Summary copied.');}
    catch{const range=document.createRange();range.selectNodeContents(summary);const selection=getSelection();selection.removeAllRanges();selection.addRange(range);window.AMASHAZI_UI.toast('Summary selected. Use your device’s copy command.');}
  });
  $('[data-download]').addEventListener('click',()=>{
    const url=URL.createObjectURL(new Blob([summary.textContent],{type:'text/plain;charset=utf-8'}));
    const a=document.createElement('a');a.href=url;a.download=`Amashazi-${kind}.txt`;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
  });
  $('[data-print]').addEventListener('click',()=>window.print());
})();
