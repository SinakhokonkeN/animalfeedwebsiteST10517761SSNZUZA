(() => {
  'use strict';
  const KEY = 'amashazi-quote-list-v1'; // Retain the original site's quote lists.
  const catalogue = window.AMASHAZI_DATA.products;
  let memory = [];
  let persistent = true;
  function normalise(input) {
    if (!Array.isArray(input)) return [];
    const result = new Map();
    input.forEach(line => {
      if (!line || !catalogue.some(product => product.id === line.id)) return;
      const number = Number(line.quantity);
      if (!Number.isFinite(number) || number < 1) return;
      const quantity = Math.min(999, Math.floor(number));
      result.set(line.id, Math.min(999, (result.get(line.id) || 0) + quantity));
    });
    return [...result].map(([id, quantity]) => ({ id, quantity }));
  }
  function read() {
    if (!persistent) return memory.map(line => ({ ...line }));
    try { memory = normalise(JSON.parse(localStorage.getItem(KEY) || '[]')); }
    catch { persistent = false; }
    return memory.map(line => ({ ...line }));
  }
  function write(lines) {
    memory = normalise(lines);
    try { localStorage.setItem(KEY, JSON.stringify(memory)); persistent = true; }
    catch { persistent = false; }
    window.dispatchEvent(new CustomEvent('quotechange'));
  }
  function getLines() {
    return read().map(line => ({ ...line, product:catalogue.find(product => product.id===line.id) }));
  }
  function validQuantity(value) { return Number.isInteger(Number(value)) && Number(value)>=1 && Number(value)<=999; }
  function add(id, quantity=1) {
    if (!catalogue.some(p=>p.id===id) || !validQuantity(quantity)) return {ok:false,message:'Enter a whole quantity between 1 and 999.'};
    const lines=read(); const existing=lines.find(line=>line.id===id);
    if (existing) existing.quantity=Math.min(999,existing.quantity+Number(quantity));
    else lines.push({id,quantity:Number(quantity)});
    write(lines);
    return {ok:true,message:persistent?'Added to your quote list.':'Added for this page. Browser storage is unavailable.'};
  }
  function update(id,quantity) {
    if (!validQuantity(quantity)) return false;
    const lines=read(); const line=lines.find(item=>item.id===id);
    if (!line) return false;
    line.quantity=Number(quantity); write(lines); return true;
  }
  function remove(id) { write(read().filter(line=>line.id!==id)); }
  function clear() { write([]); }
  function count() { return read().reduce((total,line)=>total+line.quantity,0); }
  window.AMASHAZI_QUOTE = Object.freeze({getLines,add,update,remove,clear,count,validQuantity});
  window.addEventListener('storage',event=>{ if(event.key===KEY || event.key===null) { persistent=true; window.dispatchEvent(new CustomEvent('quotechange')); } });
})();
