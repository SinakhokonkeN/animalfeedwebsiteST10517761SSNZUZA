/* Edit only confirmed business details. Browser Maps keys MUST be referrer/API restricted.
   See docs/04-GOOGLE-MAPS-SETUP.md. Never put service-account or server secrets here. */
window.AMASHAZI_CONFIG = Object.freeze({
  business: {
    email: '',
    phone: '',
    hours: '',
    address: '',
    domain: '' // Set only after the requested domain has been registered and deployed.
  },
  maps: {
    apiKey: '',
    mapId: '', // A Google Cloud map ID; DEMO_MAP_ID is only for development.
    areaQuery: 'Bulwer, KwaZulu-Natal, South Africa',
    // Broad KwaZulu-Natal view, NOT a business location.
    areaCenter: { lat: -28.5, lng: 30.8 },
    verifiedPosition: null, // Set {lat: NUMBER, lng: NUMBER} only for a verified premises.
    verifiedAddress: false
  },
  forms: {
    // Defaults to the form's same-origin action. Included Node server supports both.
    enquiryEndpoint: '',
    contactEndpoint: ''
  }
});
