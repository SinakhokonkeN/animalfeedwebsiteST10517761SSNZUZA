(() => {
  'use strict';
  const $ = (s,r=document)=>r.querySelector(s);
  const $$ = (s,r=document)=>[...r.querySelectorAll(s)];
  const products=window.AMASHAZI_DATA.products;
  const quote=window.AMASHAZI_QUOTE;
  const reduced=matchMedia('(prefers-reduced-motion: reduce)');
  const el=(tag,cls='',text='')=>{const n=document.createElement(tag);n.className=cls;n.textContent=text;return n;};
  function toast(message) {
    const node=$('.toast'); if(!node)return;
    node.textContent=message;node.classList.add('visible');
    clearTimeout(toast.timer);toast.timer=setTimeout(()=>node.classList.remove('visible'),3200);
  }
  function media(product,cls='') {
    if (!product.image) {
      const art=el('div','supplement-design');
      art.setAttribute('role','img');art.setAttribute('aria-label','Vitamins and supplements category illustration');
      const plus=el('div','plus','+');plus.setAttribute('aria-hidden','true');
      art.append(plus,el('p','','ANIMAL VITAMINS & SUPPLEMENTS'));return art;
    }
    const image=document.createElement('img');
    image.src=product.image;image.alt=product.alt;image.width=product.width;image.height=product.height;
    image.loading='lazy';image.decoding='async';image.className=cls;return image;
  }
  function reveal(root=document) {
    if (reduced.matches || document.body.classList.contains('motion-paused') || !('IntersectionObserver' in window)) return;
    const nodes=$$('.reveal:not(.is-visible)',root);
    const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{
      if(entry.isIntersecting){entry.target.classList.remove('is-pending');entry.target.classList.add('is-visible');observer.unobserve(entry.target);}
    }),{threshold:.06});
    nodes.forEach(node=>{node.classList.add('is-pending');observer.observe(node);});
  }
  function productCard(product) {
    const card=el('article','product-card');
    const link=el('a',`product-media ${product.animal}`);link.href=`product.html?id=${encodeURIComponent(product.id)}`;
    link.setAttribute('aria-label',`View ${product.name}`);link.append(media(product));
    const copy=el('div','product-copy');
    const title=el('h2');const titleLink=el('a','',product.name);titleLink.href=link.href;title.append(titleLink);
    copy.append(el('p','product-category',product.label),title,el('p','',product.description));
    const actions=el('div','product-actions');
    const detail=el('a','text-link','View category ↗');detail.href=link.href;
    const add=el('button','button lime','Add to quote +');add.type='button';add.dataset.addQuote=product.id;add.setAttribute('aria-label',`Add ${product.name} to quote`);
    actions.append(detail,add);copy.append(actions);card.append(link,copy);return card;
  }
  function catalogue() {
    const grid=$('[data-product-grid]');if(!grid)return;
    function render() {
      const search=$('#product-search').value.trim().toLowerCase();
      const category=$('#category-filter').value;
      const sort=$('#sort-products').value;
      const list=products.filter(product=>(category==='all'||product.category===category||product.animal===category)&&`${product.name} ${product.description}`.toLowerCase().includes(search));
      if(sort==='name')list.sort((a,b)=>a.name.localeCompare(b.name,'en-ZA'));
      grid.replaceChildren(...list.map(productCard));
      $('[data-product-count]').textContent=`${list.length} ${list.length===1?'category':'categories'} to explore`;
      $('[data-product-empty]').hidden=!!list.length;
    }
    function reset(){ $('#product-search').value='';$('#category-filter').value='all';$('#sort-products').value='featured';render(); }
    $('#product-search').addEventListener('input',render);
    $('#category-filter').addEventListener('change',render);
    $('#sort-products').addEventListener('change',render);
    $('#clear-filters').addEventListener('click',reset);
    $('[data-reset-products]').addEventListener('click',reset);
    render();
  }
  function detail() {
    const root=$('[data-product-detail]');if(!root)return;
    const id=new URLSearchParams(location.search).get('id');
    const product=products.find(p=>p.id===id);
    if(!product) {
      const empty=el('div','empty-state');empty.append(el('h1','','Category not found'),el('p','','Choose a feed category from our range.'));
      const a=el('a','button lime','Browse our feed ↗');a.href='products.html';empty.append(a);root.replaceChildren(empty);return;
    }
    document.title=`${product.name} | Amashazi Animal Feed Suppliers`;
    $('meta[name=description]').content=product.description;
    $('[data-product-crumb]').textContent=product.name;
    const article=el('article','detail-layout');
    const visual=el('div',`detail-media ${product.animal}`);const photo=media(product);if(product.image)photo.loading='eager';visual.append(photo);
    const copy=el('div','detail-copy');copy.append(el('p','eyebrow',product.label),el('h1','',product.name),el('p','lead',product.description));
    const info=el('dl','detail-info');
    [['Pricing','Request a quote'],['Availability','Confirm with supplier'],['Pack sizes & brands','Confirmed on enquiry']].forEach(([key,value])=>{const row=el('div');row.append(el('dt','',key),el('dd','',value));info.append(row);});
    const controls=el('div','detail-purchase');const label=el('label','','Approximate number of packs');label.htmlFor='detail-quantity';
    const input=el('input');Object.assign(input,{id:'detail-quantity',type:'number',min:'1',max:'999',step:'1',value:'1',required:true});
    const button=el('button','button lime','Add to quote list +');button.type='button';button.dataset.addQuote=product.id;button.dataset.quantitySource='detail-quantity';
    controls.append(label,input,button);copy.append(info,controls,el('p','detail-note',product.note));
    const back=el('a','text-link','Review your quote list ↗');back.href='quote.html';copy.append(back);
    article.append(visual,copy);root.replaceChildren(article);
  }
  function badges() { $$('[data-quote-count]').forEach(n=>n.textContent=String(quote.count())); }
  let editingQuote = false;
  function renderQuote() {
    if (editingQuote) {
      const total=$('[data-total-quantity]'); if(total)total.textContent=String(quote.count());
      return;
    }
    const root=$('[data-quote-items]');if(!root)return;
    const lines=quote.getLines();
    root.replaceChildren(...lines.map(line=>{
      const row=el('article','quote-item');const image=media(line.product);
      const text=el('div');text.append(el('h2','',line.product.name),el('p','','Final pack sizes, pricing and stock to be confirmed.'));
      const controls=el('div','quote-controls');const label=el('label','','Packs');label.htmlFor=`qty-${line.id}`;
      const input=el('input');Object.assign(input,{id:`qty-${line.id}`,type:'number',min:'1',max:'999',step:'1',value:String(line.quantity)});input.dataset.quoteQuantity=line.id;input.setAttribute('aria-label',`${line.product.name} quantity`);label.append(input);
      const remove=el('button','text-button','Remove');remove.type='button';remove.dataset.removeQuote=line.id;remove.setAttribute('aria-label',`Remove ${line.product.name}`);
      controls.append(label,remove);row.append(image,text,controls);return row;
    }));
    $('[data-quote-empty]').hidden=!!lines.length;
    $('[data-line-count]').textContent=String(lines.length);
    $('[data-total-quantity]').textContent=String(quote.count());
    $('[data-clear-quote]').disabled=!lines.length;
  }
  function selectionPreview() {
    const root=$('[data-selection-preview]');if(!root)return;
    const lines=quote.getLines();root.replaceChildren();
    if(!lines.length){root.append(el('p','small','No saved categories yet. Choose a category in the form, or browse our range.'));return;}
    lines.forEach(line=>{const row=el('div','selection-line');row.append(el('span','',line.product.name),el('span','',`× ${line.quantity}`));root.append(row);});
  }
  function nav() {
    const toggle=$('.menu-toggle'), menu=$('.primary-nav'), header=$('.site-header');
    const small=matchMedia('(max-width: 950px)');
    function setOpen(open,restore=false){
      document.body.classList.toggle('menu-open',open);toggle.setAttribute('aria-expanded',String(open));toggle.setAttribute('aria-label',open?'Close menu':'Open menu');
      menu.inert=small.matches&&!open;
      $('main').inert=open;$('footer').inert=open;
      if(open)menu.querySelector('a').focus();else if(restore)toggle.focus();
    }
    toggle.addEventListener('click',()=>setOpen(toggle.getAttribute('aria-expanded')!=='true',true));
    menu.addEventListener('click',e=>{if(e.target.closest('a'))setOpen(false);});
    document.addEventListener('keydown',e=>{
      if(toggle.getAttribute('aria-expanded')!=='true')return;
      if(e.key==='Escape'){e.preventDefault();setOpen(false,true);}
      if(e.key==='Tab'){
        const focusable=[...menu.querySelectorAll('a'),$('.quote-link'),toggle];
        const index=focusable.indexOf(document.activeElement);
        // Native DOM order is nav, quote, toggle; wrap at both ends.
        if(e.shiftKey && index===0){e.preventDefault();toggle.focus();}
        else if(!e.shiftKey && document.activeElement===toggle){e.preventDefault();focusable[0].focus();}
      }
    });
    small.addEventListener('change',()=>setOpen(false));setOpen(false);
    window.addEventListener('scroll',()=>header.classList.toggle('scrolled',scrollY>10),{passive:true});
  }
  function motion() {
    const button=$('.motion-control');let paused=false;
    try {paused=localStorage.getItem('amashazi-motion')==='paused';}catch{}
    function apply(){document.body.classList.toggle('motion-paused',paused);button.setAttribute('aria-pressed',String(paused));button.textContent=reduced.matches?'Reduced motion enabled':paused?'Resume motion':'Pause motion';button.disabled=reduced.matches;}
    button.addEventListener('click',()=>{paused=!paused;try{localStorage.setItem('amashazi-motion',paused?'paused':'enabled');}catch{}apply();});
    reduced.addEventListener('change',apply);apply();
  }
  function gallery() {
    const dialog=$('.lightbox');if(!dialog)return;
    const feed=products.filter(p=>p.category==='feed');let current=0,opener=null;
    function show(index){current=(index+feed.length)%feed.length;const p=feed[current];const image=$('[data-lightbox-image]');image.src=p.image;image.alt=p.alt;image.width=p.width;image.height=p.height;$('#lightbox-caption').textContent=`${current+1} / ${feed.length} · ${p.label} at feeding time`;}
    $$('[data-gallery]').forEach(button=>button.addEventListener('click',()=>{opener=button;show(Number(button.dataset.gallery));dialog.showModal();document.body.classList.add('dialog-open');}));
    $('.lightbox-close').addEventListener('click',()=>dialog.close());
    $('[data-lightbox-prev]').addEventListener('click',()=>show(current-1));
    $('[data-lightbox-next]').addEventListener('click',()=>show(current+1));
    dialog.addEventListener('keydown',e=>{if(e.key==='ArrowRight'){e.preventDefault();show(current+1);}if(e.key==='ArrowLeft'){e.preventDefault();show(current-1);}});
    dialog.addEventListener('click',e=>{if(e.target!==dialog)return;const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dialog.close();});
    dialog.addEventListener('close',()=>{document.body.classList.remove('dialog-open');opener?.focus();});
  }
  function businessDetails(){
    const business=window.AMASHAZI_CONFIG.business;
    ['phone','email','hours'].forEach(key=>{const root=$(`[data-business-${key}]`);if(!root||!business[key])return;root.hidden=false;const value=$('dd',root);if(key==='hours'){value.textContent=business[key];return;}const a=el('a','',business[key]);a.href=key==='email'?`mailto:${business[key]}`:`tel:${business[key].replace(/[^+\d]/g,'')}`;value.replaceChildren(a);});
  }
  document.addEventListener('click',event=>{
    const add=event.target.closest('[data-add-quote]');
    if(add){const input=add.dataset.quantitySource?document.getElementById(add.dataset.quantitySource):null;if(input&&!input.reportValidity())return;toast(quote.add(add.dataset.addQuote,input?Number(input.value):1).message);}
    const remove=event.target.closest('[data-remove-quote]');
    if(remove){quote.remove(remove.dataset.removeQuote);toast('Removed from your quote list.');$('[data-quote-quantity]')?.focus();}
  });
  document.addEventListener('input',event=>{
    const input=event.target.closest('[data-quote-quantity]');
    if (!input || !input.checkValidity() || !quote.validQuantity(input.value)) return;
    editingQuote=true;quote.update(input.dataset.quoteQuantity,Number(input.value));editingQuote=false;
  });
  document.addEventListener('change',event=>{
    const input=event.target.closest('[data-quote-quantity]');if(!input)return;
    if(!input.checkValidity()||!quote.validQuantity(input.value)){input.reportValidity();return;}
    const id=input.id;quote.update(input.dataset.quoteQuantity,Number(input.value));document.getElementById(id)?.focus();
  });
  $('[data-clear-quote]')?.addEventListener('click',()=>{quote.clear();toast('Quote list cleared.');});
  window.addEventListener('quotechange',()=>{badges();renderQuote();selectionPreview();});
  $$('[data-year]').forEach(n=>n.textContent=String(new Date().getFullYear()));
  window.AMASHAZI_UI=Object.freeze({toast});
  nav();motion();catalogue();detail();badges();renderQuote();selectionPreview();gallery();businessDetails();reveal();
})();
