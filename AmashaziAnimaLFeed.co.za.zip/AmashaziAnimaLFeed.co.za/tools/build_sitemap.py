"""Generate a sitemap only after the live website URL is known."""
import sys
from pathlib import Path
from urllib.parse import urlsplit
from xml.etree.ElementTree import Element, SubElement, ElementTree
if len(sys.argv)!=2:
    raise SystemExit('Usage: python tools/build_sitemap.py https://YOUR-ACTUAL-DOMAIN')
base=sys.argv[1].rstrip('/')
u=urlsplit(base)
if u.scheme not in ('https','http') or not u.hostname or u.query or u.fragment:
    raise SystemExit('Use a valid public HTTP(S) base URL without query or fragment.')
root=Path(__file__).resolve().parents[1]
xml=Element('urlset',xmlns='http://www.sitemaps.org/schemas/sitemap/0.9')
for file in sorted(root.glob('*.html')):
    if file.name in ('product.html','quote.html'):continue
    SubElement(SubElement(xml,'url'),'loc').text=base+'/'+file.name
for id in ('poultry-feed','cattle-feed','goat-feed','sheep-feed','pig-feed','vitamins-supplements'):
    SubElement(SubElement(xml,'url'),'loc').text=base+'/product.html?id='+id
ElementTree(xml).write(root/'sitemap.xml',encoding='utf-8',xml_declaration=True)
robots=root/'robots.txt'
lines=[line for line in robots.read_text().splitlines() if not line.lower().startswith('sitemap:')]
robots.write_text('\n'.join(lines)+'\nSitemap: '+base+'/sitemap.xml\n')
print('sitemap.xml and robots.txt updated for',base)
