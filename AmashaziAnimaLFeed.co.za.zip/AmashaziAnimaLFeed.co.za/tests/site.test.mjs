import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,rm,readdir,readFile} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import vm from 'node:vm';
import {createApp,validate} from '../server.mjs';
const base={name:'QA Example',email:'qa@example.com',phone:'+27 82 123 4567',message:'Testing the local request workflow.',consent:true,requestId:'qa-request-001'};
const enquiry={...base,fulfilment:'delivery',area:'Bulwer',requiredDate:'2099-12-12',items:[{id:'cattle-feed',quantity:12}]};
test('server validates enquiry requirements and rejects forged products',()=>{
 assert.deepEqual(validate(enquiry,'enquiry').errors,{});
 for(const mutation of [{email:'bad'},{consent:false},{area:''},{requiredDate:'2020-01-01'},{requiredDate:'2099-02-31'},{items:[{id:'fake-feed',quantity:1}]},{items:[{id:'cattle-feed',quantity:1.5}]},{items:[]},{phone:'not a phone'}])assert.ok(Object.keys(validate({...enquiry,...mutation},'enquiry').errors).length);
});
test('contact requires a distinct topic and full message',()=>{
 assert.deepEqual(validate({...base,subject:'General question'},'contact').errors,{});
 assert.ok(validate({...base,subject:'wrong',message:'short'},'contact').errors.subject);
 assert.ok(validate({...base,subject:'General question',message:'short'},'contact').errors.message);
});
test('real AJAX endpoints record idempotently and protect stored requests',async()=>{
 const dir=await mkdtemp(path.join(tmpdir(),'amashazi-qa-'));
 const server=createApp({dataDir:dir,rateLimit:100});await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin=`http://127.0.0.1:${server.address().port}`;
 try{
  const submit=(route,body,extra={})=>fetch(origin+route,{method:'POST',headers:{'Content-Type':'application/json',Accept:'application/json',...extra},body:JSON.stringify(body)});
  assert.equal((await (await fetch(origin+'/api/health')).json()).recording,true);
  let res=await submit('/api/enquiry',enquiry);assert.equal(res.status,201);const receipt=await res.json();assert.equal(receipt.emailSent,false);assert.match(receipt.reference,/^AM-/);
  res=await submit('/api/enquiry',enquiry);assert.equal(res.status,201);assert.equal((await res.json()).reference,receipt.reference);assert.equal((await readdir(dir)).length,1);
  res=await submit('/api/enquiry',{...enquiry,name:'Changed request'});assert.equal(res.status,409);
  res=await submit('/api/contact',{...base,subject:'General question'});assert.equal(res.status,201);
  res=await submit('/api/enquiry',{...enquiry,items:[]});assert.equal(res.status,422);
  res=await submit('/api/enquiry',enquiry,{Origin:'https://unrelated.example'});assert.equal(res.status,403);
  assert.equal((await fetch(origin+'/var/requests/private.json')).status,404);
  assert.equal((await fetch(origin+'/server.mjs')).status,404);
  assert.equal((await fetch(origin+'/%2e%2e%2fserver.mjs')).status,404);
  assert.equal((await fetch(origin+'/index.html')).status,200);
  const saved=JSON.parse(await readFile(path.join(dir,(await readdir(dir))[0]),'utf8'));assert.equal(saved.emailSent,false);
 }finally{await new Promise(r=>server.close(r));await rm(dir,{recursive:true,force:true});}
});
async function loadCart(initial='[]',blocked=false){
 let saved=initial;
 const context=vm.createContext({localStorage:{getItem:()=>{if(blocked)throw Error('blocked');return saved;},setItem:(key,value)=>{if(blocked)throw Error('blocked');saved=value;}},CustomEvent:class{constructor(type){this.type=type;}},window:{addEventListener:()=>{},dispatchEvent:()=>{}}});
 for(const name of ['products','quote'])vm.runInContext(await readFile(new URL(`../js/${name}.js`,import.meta.url),'utf8'),context);
 return context.window.AMASHAZI_QUOTE;
}
test('quote persists additions, rejects fractional quantities, normalises corrupted data',async()=>{
 const cart=await loadCart('[{"id":"cattle-feed","quantity":2},{"id":"cattle-feed","quantity":3},{"id":"unknown","quantity":999},{"id":"pig-feed","quantity":-1}]');
 assert.equal(cart.count(),5);assert.equal(cart.add('pig-feed',1.5).ok,false);assert.equal(cart.add('pig-feed',4).ok,true);assert.equal(cart.count(),9);cart.update('cattle-feed',7);assert.equal(cart.count(),11);cart.remove('pig-feed');assert.equal(cart.count(),7);cart.clear();assert.equal(cart.count(),0);
 const malformed=await loadCart('broken JSON');assert.equal(malformed.count(),0);assert.equal(malformed.add('goat-feed',2).ok,true);assert.equal(malformed.count(),2);
});
test('quote retains usable in-memory behaviour when browser storage is blocked',async()=>{
 const cart=await loadCart('[]',true);cart.add('sheep-feed',3);assert.equal(cart.count(),3);cart.update('sheep-feed',5);assert.equal(cart.count(),5);cart.clear();assert.equal(cart.count(),0);
});
