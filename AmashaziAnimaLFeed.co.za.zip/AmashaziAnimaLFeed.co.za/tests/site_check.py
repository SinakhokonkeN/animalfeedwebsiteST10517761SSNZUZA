from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit,unquote
import subprocess
ROOT=Path(__file__).resolve().parents[1]
class Page(HTMLParser):
 def __init__(self):super().__init__();self.ids=[];self.links=[];self.images=[];self.forms=[]
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if 'id'in a:self.ids.append(a['id'])
  for k in ['src','href']:
   if k in a:self.links.append(a[k])
  if tag=='img':self.images.append(a)
  if tag=='form':self.forms.append(a)
errors=[]
for f in ROOT.glob('*.html'):
 p=Page();p.feed(f.read_text())
 if len(p.ids)!=len(set(p.ids)):errors.append(f'{f.name}: duplicate IDs')
 for u in p.links:
  v=urlsplit(u)
  if v.scheme or u.startswith('//'):continue
  dest=ROOT/unquote(v.path) if v.path else f
  if not dest.exists():errors.append(f'{f.name}: missing {u}');continue
  if v.fragment and dest.suffix=='.html':
   target=Page();target.feed(dest.read_text())
   if v.fragment not in target.ids:errors.append(f'{f.name}: missing fragment {u}')
 for i in p.images:
  if 'alt' not in i or 'width' not in i or 'height' not in i:errors.append(f'{f.name}: image attributes incomplete')
 for form in p.forms:
  if not form.get('action') or form.get('method')!='post':errors.append(f'{f.name}: form destination missing')
for f in [*ROOT.glob('js/*.js'),ROOT/'server.mjs']:
 result=subprocess.run(['node','--check',str(f)],capture_output=True,text=True)
 if result.returncode:errors.append(f'{f.name}: {result.stderr}')
if errors:raise SystemExit('\n'.join(errors))
print('PASS: 10 HTML pages; local assets/anchors/IDs; image attributes; form actions; JavaScript syntax.')
