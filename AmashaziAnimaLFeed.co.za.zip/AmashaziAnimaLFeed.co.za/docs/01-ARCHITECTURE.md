# Architecture and implementation checklist

## Source inspected

The supplied V1 ZIP contained eight HTML pages, three JavaScript files, CSS, a logo, SVG image placeholders, `README.md`, `IMAGE-SHOT-LIST.md`, `CLIENT-DETAILS-NEEDED.md`, `GOOGLE-MAPS-SETUP.txt` and a source-check script. It did not contain files named `01-ARCHITECTURE.md` or `03-PART3-TRACEABILITY.md`; these V2 documents make the requested checklist explicit.

## Structure

| Location | Responsibility |
|---|---|
| Root HTML pages | Semantic page content, shared navigation, metadata, labels and form actions |
| `css/styles.css` | Design tokens, layout, photo frames, typography, motion, responsive and print rules |
| `js/config.js` | Confirmed business data and Google Maps/form endpoint configuration |
| `js/products.js` | Six honest feed-category records; no invented brands, prices or pack sizes |
| `js/quote.js` | Existing V1 storage key, input normalisation, quantity limits and memory fallback |
| `js/app.js` | Catalogue, detail, cart, navigation, gallery, motion and reusable UI behaviour |
| `js/forms.js` | Accessible client validation, review, download/copy/print, email draft and AJAX submission |
| `js/maps.js` | Click-to-load map, Google API libraries, verified marker and fallback/unload behaviour |
| `server.mjs` | Optional local HTTP server, separate endpoints, validation and private request persistence |
| `tests/` | Automated checks and a browser viewport harness |
| `docs/` | Rubric mapping, setup, provenance, launch checklist and test report |

## Page map

| Page | Primary task | Next step |
|---|---|---|
| Home | Understand the business and choose an animal category | Products, enquiry or story |
| Products | Search/filter six categories | Product details or quote |
| Product | Read a category and choose approximate packs | Quote |
| Quote | Review/edit selected categories | Enquiry |
| Enquiry | Request feed availability/pricing/fulfilment | Review, record or prepare email |
| Contact | Prepare a general message and explore the area | Review, record or prepare email |
| About | Understand audience and scope | Products |
| Supply | Understand collection/delivery enquiries | Enquiry |
| Gallery | Inspect supplied animal photos | Product details |
| Privacy | Understand data handling | Contact |

## Completed checklist

- [x] Preserve supplied logo and original livestock photos.
- [x] Keep HTML, CSS and JavaScript separate; no framework dependency.
- [x] Distinct enquiry and general-contact purposes.
- [x] HTML field constraints plus client and server validation.
- [x] Explicit action/method attributes and genuine AJAX to included endpoints.
- [x] No false “email sent”, “order confirmed”, stock or pricing status.
- [x] Persistent quantities; invalid data, duplicate categories and blocked storage handled.
- [x] Labelled fields, skip link, focus styles and keyboard-operable controls.
- [x] Visible form errors linked through `aria-describedby` and `aria-invalid`.
- [x] Small-screen menu, gallery dialog, motion pause and reduced-motion CSS.
- [x] Map stays unloaded until requested; no device location prompt.
- [x] Script/auth/network map failures retain a usable Maps link/fallback.
- [x] Private server files never served as public static content.
- [ ] Owner's key, contact details, exact location and stock information.
- [ ] Remote repository, live domain, hosting, complete rubric and final submission evidence.
