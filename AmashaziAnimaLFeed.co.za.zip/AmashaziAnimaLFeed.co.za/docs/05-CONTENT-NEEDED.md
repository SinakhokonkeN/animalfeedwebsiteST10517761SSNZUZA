# Owner details and launch checklist

## Needed to activate live integrations

- [ ] Confirmed business email (required for the email-draft recipient).
- [ ] Phone number and opening hours.
- [ ] Exact collection address; clarify the supplied “Bulwer, Pietermaritzburg” wording.
- [ ] Verified latitude/longitude or business location.
- [ ] Restricted Google Maps browser API key and map ID.
- [ ] Actual registered domain and hosting choice.
- [ ] Backend/operator workflow and email delivery provider, if live request handling is required.

## Needed for final commercial copy

- [ ] Product names/brands, approved pack sizes and current availability.
- [ ] Confirmed prices if they are to be displayed; otherwise keep quote-based pricing.
- [ ] Delivery coverage, fees, minimum quantities and collection instructions.
- [ ] Original sources and usage rights for the supplied livestock photos and logo.
- [ ] Higher-resolution poultry image if a larger placement is desired (current: 236 × 275).
- [ ] Real premises, team or product packaging images if those sections are desired. No generic photo is described as the actual store.

## Needed for the assignment

- [ ] Complete Part 2/Part 3 marking rubric and feedback.
- [ ] Original two proposals and institutional cover/submission details.
- [ ] Real budget and timeline evidence.
- [ ] Actual GitHub repository, commit history, deployed URL and submission screenshots.

The request service intentionally makes no payment, stock reservation, shipping or automatic email claims. Configure owner details in `js/config.js`; follow the Maps guide and README for endpoint/hosting setup.
