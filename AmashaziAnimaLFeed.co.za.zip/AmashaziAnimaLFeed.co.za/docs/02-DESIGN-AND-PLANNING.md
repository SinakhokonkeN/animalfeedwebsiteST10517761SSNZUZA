# Design and planning

## Direction

The supplied Agri Nova image informs the dark agricultural palette, large uppercase brand, photograph-led hero, lime actions, compact cards and generous section spacing. The Amashazi name, business purpose, logo and content stay specific to animal feed. The inspiration image is kept here as evidence; it is not used as the website itself, and its tractor, claims and statistics are not copied.

| Token | Value | Use |
|---|---|---|
| Forest | `#101e16` | Main canvas |
| Deep green | `#19291f` | Secondary surfaces |
| Lime | `#c1e389` | Actions, emphasis and focus |
| Warm ivory | `#f1f2e9` | Main type |
| Soft sage | `#b4c0b4` | Supporting copy |
| Pale cream | `#edf0e4` | FAQ contrast section |
| Type | Arial, Helvetica, sans-serif | Local fonts; no external font requests |

The source logo's green/red/gold colours are preserved inside its original light background. Motion moves the logo gently without spinning its lettering. A pause control and `prefers-reduced-motion` disable animation. Smooth scrolling is native CSS; no scroll interception or heavy animation library is used.

## Layout wireframes

| Section | Wide viewport | Phone viewport |
|---|---|---|
| Header | Brand, horizontal navigation, quote badge | Compact brand, quote badge, hamburger |
| Hero | Oversized brand above copy; photo across background; logo at right | Scaled brand, image area, short text and actions; compact logo |
| Feed categories | Five photographic cards in one row | Two-column cards, with all categories in the document |
| Story | Photo and copy in two columns | Photo then copy |
| Process | Three columns | Three numbered rows |
| FAQ | Heading beside expandable questions | Heading above questions |
| Footer | Four columns | Two columns with brand/CTA spanning |
| Catalogue | Three cards per row and filter toolbar | One card per row; stacked/paired filters |
| Forms | Context panel beside form | Context panel then one-column fields |
| Map | Map beside visit guidance | Map then guidance |

See `wireframes.svg` for exact simplified block diagrams. These describe the implemented V2 design, not historical Part 1 submissions.

## Current-site analysis (V1)

- Placeholders occupied the hero, categories and gallery; the real supplied photos were not present.
- The contact map used `YOUR_GOOGLE_MAPS_API_KEY` inside a live iframe URL.
- The contact form validated but did not deliver, show a usable message summary or implement AJAX.
- There was no rubric-named `enquiry.html`; quote preparation existed separately.
- Some malformed/blocked browser storage paths were not handled robustly.
- Site content included internal build instructions and unset contact information in customer-facing areas.
- Metadata referenced `example.com`; the actual domain and hosting were unconfirmed.

## Goals and proposed features

1. Help farmers identify the right animal category and prepare a useful feed enquiry.
2. Make the quote journey clear across desktop and phone sizes.
3. Separate product enquiries from general messages.
4. Make location information useful without inventing a store pin.
5. Keep content credible: no invented products, prices, customer counts or delivery promises.

The implemented feature inventory and page map are in `01-ARCHITECTURE.md`.

## Technical requirements

A current browser supporting CSS Grid, native `dialog`, `inert`, IntersectionObserver and localStorage; HTML/CSS/JS; Node.js 22+ for local AJAX recording; Google Maps browser key for keyed-map mode; HTTP(S) serving for integrations. Browser persistence is best effort; summaries remain downloadable. No npm dependencies are required.

## Delivery plan and budget inputs

| Work | Current state |
|---|---|
| Inspect V1, photos and supplied rubric screenshots | Complete in this update |
| CSS/HTML redesign and real-photo placement | Complete |
| JavaScript interactions, forms and map code | Complete; owner integrations awaiting configuration |
| Local checks and browser QA | Reported in `06-QA-REPORT.md` |
| Obtain complete rubric, contact/stock details, key and address | Owner/student action |
| Verify live API, publish, push repository and capture evidence | After owner configuration |

Budget must use actual supplier quotations. Collect: domain registration/renewal; selected hosting and any backend/storage plan; Google Maps project usage limits and costs; optional email delivery provider; content licensing/photography; maintenance. None was supplied, so no rand amounts are invented. This is a budget-input checklist, not a completed budget criterion. No retrospective deadline or commit history is fabricated.
