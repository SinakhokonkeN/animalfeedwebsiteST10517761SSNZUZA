# Google Maps setup

## Included integration

`contact.html` provides a map region, an explicit Load Google map button, status messages, an Unload map control and an external Google Maps link. `js/maps.js` implements the Maps JavaScript API. It does not load any Google resource until the visitor asks to view a map.

There are two modes:

1. **No key configured:** a keyless Google area iframe for Bulwer. This is a fallback, not the Maps JavaScript API. An external Maps URL remains available if the embed fails.
2. **Key configured:** asynchronous Maps JavaScript API loader, `google.maps.importLibrary('maps')`, interactive map, and `google.maps.importLibrary('marker')` / `AdvancedMarkerElement` only when an exact verified position is supplied.

No key was in the inputs. The keyed branch has not been live-tested against an owner Google project. The code handles script errors, timeout and `gm_authFailure` by displaying the fallback. The default API map is a broad KwaZulu-Natal area view, with no claimed business marker.

## Owner steps

1. Use the owner's Google Cloud/Maps project. Meet Google's current project/billing requirements and enable **Maps JavaScript API**.
2. Create a browser API key with **website (HTTP referrer) restrictions**. Restrict its API scope to Maps JavaScript API. Do not use an unrestricted key or a server/service-account secret in the website.
3. Allow only the actual deployed origin(s) and the local development origins you use, for example `http://localhost:3000/*` and `http://127.0.0.1:5500/*`. Remove unneeded development origins when appropriate. Add `www` only if that hostname is actually used.
4. Create an appropriate JavaScript map ID. `DEMO_MAP_ID` is the code's development fallback, not a production map configuration.
5. Put the browser key and map ID in `js/config.js` under `maps.apiKey` and `maps.mapId`.
6. Confirm the exact collection address and its coordinates with the owner. Set `business.address`, `maps.verifiedPosition` and `maps.verifiedAddress: true` only then. The V1 README says “Bulwer, Pietermaritzburg, KwaZulu-Natal”; no exact premises were provided. Confirm this location wording rather than guessing a street address.
7. Update the visitor-facing location paragraph on `contact.html` when a premises is confirmed; it currently correctly describes an area map.
8. Run through HTTP, click Load Google map, and inspect the browser console and Cloud usage. Verify zoom, controls, the correct location, the map ID and authorised host restrictions. An invalid key must not leave an empty unusable panel.
9. Test the production hostname separately. A local success does not verify deployment referrers.

Browser Maps keys are visible by design; restrictions protect their permitted usage. No key, project, paid service, billing account or domain was created as part of this file update.

## Official references consulted

- Google Maps JavaScript API loading: https://developers.google.com/maps/documentation/javascript/load-maps-js-api
- Advanced marker overview and map ID requirement: https://developers.google.com/maps/documentation/javascript/advanced-markers/overview

Consulted 21 October 2026. The official library-loading and marker APIs informed the implementation. Live activation remains dependent on the owner's configuration.
