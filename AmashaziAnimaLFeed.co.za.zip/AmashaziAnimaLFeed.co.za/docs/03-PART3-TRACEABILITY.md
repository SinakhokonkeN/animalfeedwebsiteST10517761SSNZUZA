# Supplied rubric traceability — no score claimed

## Evidence boundary

The ten attached screenshots show form/repository/submission instructions (including printed page 17) and the beginning of the **Part 1** marking sheet (printed pages 19–26). They do not show the entire Part 2/Part 3 rubric. The matrix below only assesses requirements visible in those supplied images. Originals are retained under `docs/rubric/`.

| Visible requirement | Implementation/evidence | State / outstanding item |
|---|---|---|
| A form on `enquiry.html` for services/products | Dedicated feed form, category/quote selection, approximate packs, fulfilment, area and preferred date | Implemented |
| Enquiry response related to cost, availability or relevant aspect | Summary explicitly states quotation needed, stock unconfirmed, pack sizes and fulfilment to be agreed; local server returns a reference | Implemented without fabricated prices or stock |
| Separate form on `contact.html` | Name/email/phone, message topic, full message | Implemented |
| Compile contact information into an email to recipient in code | `business.email` in `js/config.js`; encoded `mailto:` subject/body after validation | Code implemented; real recipient not supplied, email app delivery not tested |
| Appropriate input/textarea/select controls | Semantic labelled native controls in both forms | Implemented |
| HTML5 validation | Required, type, minlength, maxlength, min/max/step constraints | Implemented |
| JavaScript client validation / user errors | `forms.js`, field-level errors, focus to first invalid field, live status | Implemented and exercised in browser |
| Form action specifies destination | `action="api/enquiry"` / `action="api/contact"`, `method="post"` | Implemented; Node server needed for local submission |
| AJAX asynchronous submission | `fetch` sends JSON, handles timeout/failure, preserves summary and displays real server receipt | Both endpoints exercised in browser and Node HTTP tests |
| Regular descriptive GitHub commits | No repository was attached or connected for this task | Not claimed; student must commit their actual work |
| Updated README | Root README covers V2 features, run steps and limitations | Complete |
| Changelog including feedback edits | Root CHANGELOG records this update | Complete for known changes; Part 2 lecturer feedback not supplied |
| Updated references | `docs/07-REFERENCES.md`, photo placement/provenance | Complete for supplied/consulted material |
| Push remote repository | No remote supplied | Pending |
| Submit HTML and GitHub repository link | Complete local source supplied in ZIP | Submission/link pending |
| Deploy to a free platform | Local runnable project, static upload instructions | Hosting not performed or claimed |
| Project goals/objectives | `02-DESIGN-AND-PLANNING.md` | V2 documentation supplied; original graded proposal not reconstructed |
| Current-site analysis | Findings from the inspected V1 ZIP | Documented |
| Proposed features, design aesthetic, technical requirements | Architecture, design tokens, layout tables and source | Documented |
| Wireframes and sitemap | `wireframes.svg`, page map and planned XML sitemap | V2 planning evidence supplied |
| Timeline and budget | Delivery plan plus cost-input checklist | Exact timeline/budget quotations remain student inputs |
| Two proposals submitted before Part 1 due date | Not evidenced by the supplied ZIP/screenshots | Cannot be satisfied retroactively by this update |
| Content research/sourcing | Only source business facts and supplied images; documented Google API references | Photo rights/original-source URLs need owner confirmation |
| File/folder structure | Root pages; named css/js/assets/docs/tests/tools folders | Implemented |
| Semantic HTML5 layout | header/nav/main/section/article/aside/footer and named headings | Implemented |
| Correct content tags and relevant content | Text, links, images, forms and clear page-specific content | Implemented; client particulars remain outstanding |

## Final student checks

- [ ] Supply full marking rubric and lecturer's Part 2 feedback for a complete criterion audit.
- [ ] Fill in actual student name, number and repository details where required by the institution.
- [ ] Add the confirmed business email so the email-compose criterion can be demonstrated.
- [ ] Configure/test restricted Google key and confirmed location.
- [ ] Use the Node server to demonstrate AJAX, or deploy equivalent endpoints.
- [ ] Record actual commits; push the real repository; submit its URL.
- [ ] Deploy and verify the final URL; do not submit the internal QA address.
- [ ] Include original proposals, actual budget, source permissions and required academic declarations.

No predicted mark is attached to this project. Passing local checks does not guarantee a lecturer's score.
