# Sources, assets and placement

Updated 21 October 2026.

## Supplied project and design source

- `Amashazi_Animal_Feed_Build_V1(1).zip`: source site, original logo, existing business facts and missing-content checklist. V2 updates this project rather than substituting another business.
- `Agri nova website inspo.jpg`: supplied design reference. The image visibly contains the credit `@webdesign_786`. It informs the visual direction only; no claims of ownership or original-source licensing are made.
- Ten supplied rubric screenshots: retained under `docs/rubric/`. Their content is used as assignment evidence, not rendered as public website images.

## Image placement

| Supplied file | Dimensions | Website filename | Main uses |
|---|---:|---|---|
| Sheep feed.jpg | 1200 × 800 | assets/images/sheep-feed.jpg | Hero background, sheep card/detail, gallery |
| Cattle feed.jpg | 940 × 788 | assets/images/cattle-feed.jpg | Cattle card/detail, story photo, gallery |
| Goat feed.jpg | 736 × 981 | assets/images/goat-feed.jpg | Goat card/detail, about photo, gallery |
| Pig feed.jpg | 620 × 828 | assets/images/pig-feed.jpg | Pig card/detail and gallery |
| Poultry feed.jpg | 236 × 275 | assets/images/poultry-feed.jpg | Compact poultry frames, card/detail and gallery |
| Existing ZIP logo | 960 × 960 | assets/images/amashazi-logo.jpg | Header, footer, animated hero badge, favicon |

The original photo bytes are retained. CSS controls presentation using explicit dimensions, `object-fit`, consistent frames and appropriate focal positions. Images have alt text; below-fold images load lazily. Poultry detail/gallery images are capped at their natural dimensions. At very high-density displays, source resolution remains a limit. No supersized derivative is presented as extra detail.

These are supplied livestock images, not verified Amashazi property/customer photographs. The owner should confirm usage rights and record original photographer/source URLs before public publication. The supplements tile is a simple code-rendered category illustration; no product packaging was fabricated.

## Official technical sources

- Google for Developers, Maps JavaScript API loading: https://developers.google.com/maps/documentation/javascript/load-maps-js-api
- Google for Developers, advanced markers: https://developers.google.com/maps/documentation/javascript/advanced-markers/overview

Retrieved 21 October 2026. Used for asynchronous API loading, library import and modern marker/map ID requirements. The standalone application uses browser-native HTML, CSS and JavaScript plus Node's built-in server/filesystem modules; no external JavaScript library is bundled.
