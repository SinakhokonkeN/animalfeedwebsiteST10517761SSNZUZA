# Verification — 21 October 2026

| Executed check | Result |
|---|---|
| Node validation / local HTTP integration suite | 5 tests passed, 0 failed |
| Enquiry/contact HTTP POST | Recorded with genuine receipt; no email-sent claim |
| Repeated request ID | No duplicate; changed content rejected |
| Invalid fields, dates, products, quantities | Rejected |
| Cross-origin requests / private source paths | Rejected |
| Quote normalisation / blocked browser storage | Passed |
| HTML assets, anchors, IDs, form actions, image attributes and JS syntax | Passed |
| Desktop browser, 1363px | Inspected; supplied images loaded; no horizontal overflow |
| Home at 390px and 320px | Inspected; no horizontal overflow |
| Phone hamburger open/close and Escape | Exercised; expanded menu inspected |
| 320px products/detail/quote/enquiry/contact/gallery | No horizontal overflow measured |
| 768px home/products/enquiry; 1024px home | No horizontal overflow measured |
| Search | Cattle search produced one category |
| Add category, navigate, edit quantity | Persisted; four packs carried to enquiry after repair of initial blur-update issue |
| Invalid enquiry | Inline errors and first-invalid-field focus observed |
| Valid enquiry and separate contact form | Summaries prepared; both AJAX calls returned actual local receipts |
| Map Load control | Area iframe created and Unload control exposed |

Responsive checks used same-origin iframe CSS viewports in managed Chrome, not physical Android/iPhone/Safari devices. Synthetic test data only was submitted. Runtime requests are excluded from the ZIP.

## Unverified and owner-dependent

- No owner Google key: keyed API authorisation, project configuration and exact store marker not live-tested. The keyless embed is a distinct fallback.
- No owner email: final-recipient email composition and actual email delivery not tested.
- Gallery keyboard support, motion pause and reduced-motion handling are implemented; no exhaustive accessibility certification or OS-setting test is claimed.
- No Lighthouse score, full WCAG claim, rubric percentage, GitHub push or public deployment is claimed.
- The Node server records requests locally; it is not an automatic email/payment service.
